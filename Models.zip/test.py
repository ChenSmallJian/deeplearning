import sys
from keras.applications import vgg16
from keras.models import Model,Sequential
from keras.layers import Conv2D, Conv2DTranspose, Input, Cropping2D, add, Dropout, Reshape, Activation

from keras.optimizers import SGD
from keras.callbacks import ModelCheckpoint, TensorBoard

import LoadBatches
import math

def FCN8_helper(nClasses,  input_height, input_width):

    img_input = Input(shape=(input_height, input_width, 3))

    '''
    include_top：是否保留顶层的3个全连接网络
    weights：None代表随机初始化，即不加载预训练权重。'imagenet'代表加载预训练权重
    input_tensor：可填入Keras tensor作为模型的图像输出tensor
    input_shape：可选，仅当include_top=False有效，应为长为3的tuple，指明输入图片的shape，图片的宽高必须大于48，如(200,200,3)
    '''
    model = vgg16.VGG16(
        include_top=False,
        weights='imagenet',input_tensor=img_input,
        pooling=None,
        classes=1000)
    assert isinstance(model,Model)

    o = Conv2D(filters=4096, kernel_size=(7, 7), padding="same", activation="relu", name="fc6")(model.output)
    o = Dropout(rate=0.5)(o)
    o = Conv2D(filters=4096, kernel_size=(1, 1), padding="same", activation="relu", name="fc7")(o)
    o = Dropout(rate=0.5)(o)

    o = Conv2D(filters=nClasses, kernel_size=(1, 1), padding="same", activation="relu", kernel_initializer="he_normal",
               name="score_fr")(o)

    o = Conv2DTranspose(filters=nClasses, kernel_size=(2, 2), strides=(2, 2), padding="valid", activation=None,
                        name="score2")(o)

    fcn8 = Model(inputs=img_input, outputs=o)
    # mymodel.summary()
    return fcn8

def FCN8(nClasses, input_height, input_width):

    fcn8=FCN8_helper(nClasses, input_height, input_width)

    # Conv to be applied on Pool4
    skip_con1 = Conv2D(nClasses, kernel_size=(1, 1), padding="same", activation=None,kernel_initializer="he_normal",
                       name="score_pool4")( fcn8.get_layer("block4_pool").output)
    Summed = add(inputs=[skip_con1, fcn8.output])

    x = Conv2DTranspose(nClasses, kernel_size=(2, 2), strides=(2, 2), padding="valid", activation=None,
                        name="score4")(Summed)

    ###
    skip_con2 = Conv2D(nClasses, kernel_size=(1, 1), padding="same", activation=None,kernel_initializer="he_normal",
                       name="score_pool3")( fcn8.get_layer("block3_pool").output)
    Summed2 = add(inputs=[skip_con2, x])

    #####
    Up = Conv2DTranspose(nClasses, kernel_size=(8, 8), strides=(8, 8),
                         padding="valid", activation=None, name="upsample")(Summed2)

    Up = Reshape((-1, nClasses))(Up)
    Up = Activation("softmax")(Up)

    mymodel=Model(inputs=fcn8.input,outputs=Up)

    return mymodel

def FCN32(nClasses, input_height, input_width):

    img_input = Input(shape=( input_height, input_width,3))

    model = vgg16.VGG16(
        include_top=False,
        weights='imagenet',input_tensor=img_input,
        pooling=None,
        classes=1000)
    assert isinstance(model,Model)

    o=Conv2D(filters=4096,kernel_size=(7,7),padding="same",activation="relu",name="fc6")(model.output)
    o=Dropout(rate=0.5)(o)

    o = Conv2D(filters=4096, kernel_size=(1, 1), padding="same", activation="relu", name="fc7")(o)
    o=Dropout(rate=0.5)(o)


    o = Conv2D(filters=nClasses, kernel_size=(1,1), padding="same",activation="relu",kernel_initializer="he_normal",
               name="score_fr")(o)

    o=Conv2DTranspose(filters=nClasses,kernel_size=(32,32),strides=(32,32),padding="valid",activation=None,
                      name="score2")(o)


    o=Reshape((-1,nClasses))(o)
    o=Activation("softmax")(o)

    fcn8=Model(inputs=img_input,outputs=o)
    # mymodel.summary()
    return fcn8

#-------------------------------------------------------------------------------
def load_data_source(data_source):
    """
    Load a data source given it's name
    """
    source_module = __import__('source_'+data_source)
    get_source    = getattr(source_module, 'get_source')
    return get_source()

if __name__ == '__main__':
    print('[i] Configuring data source...')
    try:
        # 这一句执行完毕后，source就相当于DIBCOSource，可以调用其方法
        source = load_data_source('dibco')
        # 通过source调用方法
        source.load_data('data', 1, 0.2)  # 第二个参数为验证集所占比例
        print('[i] # training samples:   ', source.num_training)
        print('[i] # validation samples: ', source.num_validation)
        print('[i] # classes:            ', source.num_classes)
        print('[i] Image size:           ', source.image_size)
        train_generator = source.train_generator
        valid_generator = source.valid_generator
        label_colors = source.label_colors
    except (ImportError, AttributeError, RuntimeError) as e:
        print('[!] Unable to load data source:', str(e))
        sys.exit(1)
    
    print('[i] creating model...')
    model = FCN8(2,224, 224)

    model.compile(loss='categorical_crossentropy',optimizer="adadelta",metrics=['acc'])

    #############################################################################
    train_images_path = "data/train/image/"
    train_segs_path = "data/train/gt_image/"
    train_batch_size = 4

    #############################################################################
    n_classes =2
    epochs = 10

    key="segnet"

    input_height=224
    input_width=224
    #############################################################################
    val_images_path = "data/test/image/"
    val_segs_path = "data/test/gt_image/"
    val_batch_size = 4
    #############################################################################

    G = LoadBatches.imageSegmentationGenerator(train_images_path,
                train_segs_path, train_batch_size, n_classes=n_classes, input_height=input_height,input_width=input_width)

    G_test=LoadBatches.imageSegmentationGenerator(val_images_path,
                val_segs_path, val_batch_size, n_classes=n_classes, input_height=input_height,input_width=input_width)

    checkpoint = ModelCheckpoint(filepath="output/%s_model.h5" % key, monitor='acc', mode='auto', save_best_only='True')
    tensorboard = TensorBoard(log_dir='output/log_%s_model' % key)

    model.fit_generator(generator=G,
                steps_per_epoch=math.ceil(367./train_batch_size),
                epochs=epochs,callbacks=[checkpoint,tensorboard],
                verbose=2,
                validation_data=G_test,
                validation_steps=8,
                shuffle=True)